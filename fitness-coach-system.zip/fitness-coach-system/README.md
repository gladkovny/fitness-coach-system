# 🏋️ FITNESS COACH SYSTEM

Коробочная SaaS-система для фитнес-тренеров с возможностью быстрого развёртывания.

## 🎯 Цель проекта

Трансформировать хаотичный workflow тренера в системный, масштабируемый бизнес с измеримыми результатами клиентов.

## 📊 Текущий статус

| Фаза | Статус | Описание |
|------|--------|----------|
| Phase 1: MVP Online | ✅ Готово | Dashboard, Tracker, API |
| Phase 2: Offline Module | 🔄 ~85% | Тренировки в зале |
| Phase 3: Hybrid | ⏳ Планируется | Объединение online+offline |
| Phase 4: Franchise | ⏳ Планируется | Масштабирование |

## 🛠️ Технологии

- **Backend:** Google Apps Script
- **Frontend:** Vanilla HTML/CSS/JS
- **Database:** Google Sheets
- **Hosting:** Netlify
- **Charts:** Chart.js

## 📁 Структура

```
├── apps-script/     # Google Apps Script (clasp)
├── frontend/        # HTML интерфейсы
│   ├── tracker/     # Трекер для тренера
│   ├── dashboard/   # Dashboard клиента
│   └── assessment/  # Оценка клиента
├── docs/            # Документация
└── data/            # CSV справочники
```

## 🚀 Быстрый старт

### Установка clasp
```bash
npm install -g @google/clasp
clasp login
```

### Деплой Apps Script
```bash
cd apps-script
clasp push
```

### Локальный просмотр frontend
```bash
cd frontend
npx live-server
```

## 📝 Разработка

Подробные инструкции для AI-ассистента в файле `.cursorrules`

## 👤 Автор

Николай — фитнес-тренер, Бали, Индонезия

---

*Проект разрабатывается с помощью Claude AI (Anthropic)*
