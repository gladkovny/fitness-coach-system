// ============================================
// UNIFIED APPS SCRIPT V9.0 ПОЛНАЯ ВЕРСИЯ
// Полная система: Чтение + Запись + ActualNutrition
// ============================================
// 
// V9.0 КРИТИЧЕСКИЕ ИСПРАВЛЕНИЯ:
// - ✅ getWorkoutHistory() - корректный парсинг дат DD.MM.YYYY
// - ✅ Даты конвертируются в ISO формат для правильной сортировки
// - ✅ getWorkoutPrograms() - гарантированный поиск VideoURL
// - ✅ Добавлена нормализация названий колонок (trim, lowercase)
// - ✅ История тренировок теперь работает корректно
//
// V8.9: Умный поиск колонок по нескольким названиям
// V8.8: id вместо type, включение упражнений в программы
// V8.7: formatTime(), корректное время
// V8.6: ActualNutrition
// V8.5: Гибкая структура колонок
// ============================================

// ============================================
// УТИЛИТЫ
// ============================================

/**
 * Форматирует значение времени в строку HH:MM
 */
function formatTime(value) {
  if (!value) return '';
  
  if (typeof value === 'string') {
    const match = value.match(/^(\d{1,2}):(\d{2})$/);
    if (match) return value;
  }
  
  if (value instanceof Date) {
    const hours = value.getHours();
    const mins = value.getMinutes();
    return `${String(hours).padStart(2, '0')}:${String(mins).padStart(2, '0')}`;
  }
  
  const num = parseFloat(value);
  if (!isNaN(num) && num >= 0 && num < 1) {
    const totalMins = Math.round(num * 24 * 60);
    const hours = Math.floor(totalMins / 60);
    const mins = totalMins % 60;
    return `${String(hours).padStart(2, '0')}:${String(mins).padStart(2, '0')}`;
  }
  
  return String(value);
}

/**
 * Умный поиск индекса колонки по нескольким возможным названиям
 * Нормализует названия (trim, lowercase) для надёжного поиска
 */
function findColumnIndex(headers, ...possibleNames) {
  const normalizedHeaders = headers.map(h => String(h).trim().toLowerCase());
  
  for (const name of possibleNames) {
    const normalizedName = String(name).trim().toLowerCase();
    const idx = normalizedHeaders.indexOf(normalizedName);
    if (idx >= 0) return idx;
  }
  return -1;
}

/**
 * Конвертирует дату из разных форматов в строку для сортировки
 * Поддерживает: Date объекты, DD.MM.YYYY, YYYY-MM-DD
 */
function parseDateToISO(dateValue) {
  if (!dateValue) return '';
  
  // Если Date объект
  if (dateValue instanceof Date) {
    return dateValue.toISOString().split('T')[0];
  }
  
  const str = String(dateValue).trim();
  
  // Формат DD.MM.YYYY
  if (str.match(/^\d{2}\.\d{2}\.\d{4}$/)) {
    const parts = str.split('.');
    return `${parts[2]}-${parts[1]}-${parts[0]}`;
  }
  
  // Формат YYYY-MM-DD - уже ISO
  if (str.match(/^\d{4}-\d{2}-\d{2}$/)) {
    return str;
  }
  
  // Попытка распарсить как Date
  const parsed = new Date(str);
  if (!isNaN(parsed.getTime())) {
    return parsed.toISOString().split('T')[0];
  }
  
  return str;
}

/**
 * Форматирует дату в DD.MM.YYYY для отображения
 */
function formatDateDisplay(dateValue) {
  if (!dateValue) return '';
  
  if (dateValue instanceof Date) {
    const dd = String(dateValue.getDate()).padStart(2, '0');
    const mm = String(dateValue.getMonth() + 1).padStart(2, '0');
    const yyyy = dateValue.getFullYear();
    return `${dd}.${mm}.${yyyy}`;
  }
  
  const str = String(dateValue).trim();
  
  // Уже в формате DD.MM.YYYY
  if (str.match(/^\d{2}\.\d{2}\.\d{4}$/)) {
    return str;
  }
  
  // Формат YYYY-MM-DD
  if (str.match(/^\d{4}-\d{2}-\d{2}$/)) {
    const parts = str.split('-');
    return `${parts[2]}.${parts[1]}.${parts[0]}`;
  }
  
  return str;
}

// ============================================
// РОУТЕР
// ============================================

function doGet(e) {
  const action = e.parameter.action;
  
  if (action === 'getGoals') return getGoals();
  if (action === 'getNutrition') return getNutrition();
  if (action === 'getQuotes') return getQuotes();
  if (action === 'getExercises') return getExercises();
  if (action === 'getWorkoutPrograms') return getWorkoutPrograms();
  if (action === 'getMuscleMapping') return getMuscleMapping();
  if (action === 'getSettings') return getSettings();
  if (action === 'getTemplates') return getTemplates();
  if (action === 'getWorkouts') return getWorkoutHistory();
  if (action === 'getDaily') return getDailyData();
  if (action === 'getActualNutrition') return getActualNutrition();
  
  return getWeeklyData();
}

function doPost(e) {
  try {
    const data = JSON.parse(e.postData.contents);
    const action = data.action;
    
    if (action === 'saveWorkout') return saveWorkout(data.workout);
    if (action === 'saveDaily') return saveDailyData(data);
    if (action === 'saveActualNutrition') return saveActualNutrition(data);
    
    return saveWeeklyData(data);
    
  } catch (error) {
    return ContentService.createTextOutput(JSON.stringify({
      success: false,
      error: error.toString()
    })).setMimeType(ContentService.MimeType.JSON);
  }
}

// ============================================
// READ ENDPOINTS
// ============================================

function getGoals() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName('Goals');
  
  if (!sheet) {
    return ContentService.createTextOutput(JSON.stringify({
      error: 'Goals sheet not found'
    })).setMimeType(ContentService.MimeType.JSON);
  }
  
  const data = sheet.getDataRange().getValues();
  const goals = {};
  
  for (let i = 1; i < data.length; i++) {
    const key = data[i][0];
    const value = data[i][1];
    if (key) goals[key] = value;
  }
  
  return ContentService.createTextOutput(JSON.stringify(goals))
    .setMimeType(ContentService.MimeType.JSON);
}

function getNutrition() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName('Nutrition');
  
  if (!sheet) {
    return ContentService.createTextOutput(JSON.stringify({
      error: 'Nutrition sheet not found'
    })).setMimeType(ContentService.MimeType.JSON);
  }
  
  const data = sheet.getDataRange().getValues();
  const nutrition = {};
  
  for (let i = 1; i < data.length; i++) {
    const key = data[i][0];
    const value = data[i][1];
    if (key) nutrition[key] = value;
  }
  
  return ContentService.createTextOutput(JSON.stringify(nutrition))
    .setMimeType(ContentService.MimeType.JSON);
}

function getQuotes() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName('Quotes');
  
  if (!sheet) {
    return ContentService.createTextOutput(JSON.stringify({ quotes: [] }))
      .setMimeType(ContentService.MimeType.JSON);
  }
  
  const data = sheet.getDataRange().getValues();
  const quotes = [];
  
  for (let i = 1; i < data.length; i++) {
    quotes.push({
      id: data[i][0],
      quote: data[i][1],
      category: data[i][2],
      language: data[i][3]
    });
  }
  
  return ContentService.createTextOutput(JSON.stringify({quotes}))
    .setMimeType(ContentService.MimeType.JSON);
}

function getExercises() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName('Exercises');
  
  if (!sheet) {
    return ContentService.createTextOutput(JSON.stringify({ exercises: [] }))
      .setMimeType(ContentService.MimeType.JSON);
  }
  
  const data = sheet.getDataRange().getValues();
  const headers = data[0].map(h => String(h).trim());
  
  const typeIdx = findColumnIndex(headers, 'Type', 'Program');
  const nameIdx = findColumnIndex(headers, 'Name', 'Exercise');
  const setsIdx = findColumnIndex(headers, 'Sets');
  const repsIdx = findColumnIndex(headers, 'Reps');
  const formulaIdx = findColumnIndex(headers, 'Formula');
  const videoIdx = findColumnIndex(headers, 'VideoURL', 'VideoUrl', 'Video', 'Videourl');
  const notesIdx = findColumnIndex(headers, 'Notes');
  
  const exercises = [];
  
  for (let i = 1; i < data.length; i++) {
    const row = data[i];
    exercises.push({
      type: typeIdx >= 0 ? row[typeIdx] : '',
      name: nameIdx >= 0 ? row[nameIdx] : '',
      sets: setsIdx >= 0 ? row[setsIdx] : 3,
      reps: repsIdx >= 0 ? row[repsIdx] : '8-12',
      formula: formulaIdx >= 0 ? row[formulaIdx] : 'standard',
      videoUrl: videoIdx >= 0 ? row[videoIdx] : '',
      notes: notesIdx >= 0 ? row[notesIdx] : ''
    });
  }
  
  return ContentService.createTextOutput(JSON.stringify({exercises}))
    .setMimeType(ContentService.MimeType.JSON);
}

// ============================================
// V9.0 - ПРОГРАММЫ + УПРАЖНЕНИЯ С ВИДЕО
// ============================================

function getWorkoutPrograms() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const programsSheet = ss.getSheetByName('WorkoutPrograms');
  const exercisesSheet = ss.getSheetByName('Exercises');
  
  if (!programsSheet) {
    return ContentService.createTextOutput(JSON.stringify({
      programs: [],
      source: 'error'
    })).setMimeType(ContentService.MimeType.JSON);
  }
  
  // ========== ЗАГРУЗКА УПРАЖНЕНИЙ ==========
  const exercisesByProgram = {};
  
  if (exercisesSheet) {
    const exData = exercisesSheet.getDataRange().getValues();
    const exHeaders = exData[0].map(h => String(h).trim());
    
    // V9.0: Расширенный поиск колонок
    const typeIdx = findColumnIndex(exHeaders, 'Type', 'Program');
    const nameIdx = findColumnIndex(exHeaders, 'Name', 'Exercise');
    const setsIdx = findColumnIndex(exHeaders, 'Sets');
    const repsIdx = findColumnIndex(exHeaders, 'Reps');
    const formulaIdx = findColumnIndex(exHeaders, 'Formula');
    // V9.0: Поиск VideoURL с разными вариантами написания
    const videoIdx = findColumnIndex(exHeaders, 'VideoURL', 'VideoUrl', 'Video', 'Videourl', 'video', 'videourl');
    const notesIdx = findColumnIndex(exHeaders, 'Notes');
    
    for (let i = 1; i < exData.length; i++) {
      const row = exData[i];
      const programId = String(row[typeIdx] || '').trim();
      
      if (!programId) continue;
      
      if (!exercisesByProgram[programId]) {
        exercisesByProgram[programId] = [];
      }
      
      // V9.0: Гарантированное получение видео
      const videoValue = videoIdx >= 0 ? String(row[videoIdx] || '').trim() : '';
      
      exercisesByProgram[programId].push({
        name: nameIdx >= 0 ? String(row[nameIdx] || '').trim() : '',
        sets: setsIdx >= 0 ? (row[setsIdx] || 3) : 3,
        reps: repsIdx >= 0 ? (row[repsIdx] || '8-12') : '8-12',
        video: videoValue,  // ✅ Поле video для HTML трекера
        formula: formulaIdx >= 0 ? (row[formulaIdx] || 'standard') : 'standard',
        notes: notesIdx >= 0 ? (row[notesIdx] || '') : ''
      });
    }
  }
  
  // ========== ЗАГРУЗКА ПРОГРАММ ==========
  const progData = programsSheet.getDataRange().getValues();
  const progHeaders = progData[0].map(h => String(h).trim());
  
  const progIdIdx = findColumnIndex(progHeaders, 'Type', 'ID', 'Program');
  const progNameIdx = findColumnIndex(progHeaders, 'Name', 'Title');
  const progDescIdx = findColumnIndex(progHeaders, 'Description', 'Desc');
  const progEmojiIdx = findColumnIndex(progHeaders, 'Emoji', 'Icon');
  
  const programs = [];
  
  for (let i = 1; i < progData.length; i++) {
    const row = progData[i];
    const programId = String(row[progIdIdx >= 0 ? progIdIdx : 0] || '').trim();
    if (!programId) continue;
    
    programs.push({
      id: programId,  // ✅ id для HTML трекера
      name: progNameIdx >= 0 ? (row[progNameIdx] || programId) : programId,
      displayName: programId,
      description: progDescIdx >= 0 ? (row[progDescIdx] || '') : '',
      emoji: progEmojiIdx >= 0 ? (row[progEmojiIdx] || '🏋️') : '🏋️',
      exercises: exercisesByProgram[programId] || []
    });
  }
  
  return ContentService.createTextOutput(JSON.stringify({
    programs: programs,
    source: 'sheets'
  })).setMimeType(ContentService.MimeType.JSON);
}

function getMuscleMapping() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName('MuscleMapping');
  
  if (!sheet) {
    return ContentService.createTextOutput(JSON.stringify({ mapping: [] }))
      .setMimeType(ContentService.MimeType.JSON);
  }
  
  const data = sheet.getDataRange().getValues();
  const mapping = [];
  
  for (let i = 1; i < data.length; i++) {
    mapping.push({
      exercise: data[i][0],
      muscle: data[i][1],
      priority: data[i][2],
      involvement: data[i][3]
    });
  }
  
  return ContentService.createTextOutput(JSON.stringify({mapping}))
    .setMimeType(ContentService.MimeType.JSON);
}

function getSettings() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName('Settings');
  
  if (!sheet) {
    return ContentService.createTextOutput(JSON.stringify({ settings: {} }))
      .setMimeType(ContentService.MimeType.JSON);
  }
  
  const data = sheet.getDataRange().getValues();
  const settings = {};
  
  for (let i = 1; i < data.length; i++) {
    const key = data[i][0];
    const value = data[i][1];
    if (key) settings[key] = value;
  }
  
  return ContentService.createTextOutput(JSON.stringify({settings}))
    .setMimeType(ContentService.MimeType.JSON);
}

function getTemplates() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName('Templates');
  
  if (!sheet) {
    return ContentService.createTextOutput(JSON.stringify({ templates: {} }))
      .setMimeType(ContentService.MimeType.JSON);
  }
  
  const data = sheet.getDataRange().getValues();
  const templates = {};
  
  for (let i = 1; i < data.length; i++) {
    const key = data[i][0];
    const template = data[i][1];
    const language = data[i][2];
    if (key) templates[key] = {template, language};
  }
  
  return ContentService.createTextOutput(JSON.stringify({templates}))
    .setMimeType(ContentService.MimeType.JSON);
}

// ============================================
// ТРЕНИРОВКИ (Workouts)
// ============================================

function saveWorkout(workout) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let ws = ss.getSheetByName('Workouts');
  
  if (!ws) {
    ws = ss.insertSheet('Workouts');
    ws.appendRow(['Date', 'Type', 'Exercise', 'Set', 'Weight', 'Reps', 'Tonnage', 'Total', 'Notes', 'Comments']);
    ws.getRange(1, 1, 1, 10).setFontWeight('bold').setBackground('#f39c12');
  }
  
  const allData = ws.getDataRange().getValues();
  const headers = allData[0].map(h => String(h).trim());
  
  const colIndices = {
    date: findColumnIndex(headers, 'Date'),
    type: findColumnIndex(headers, 'Type'),
    exercise: findColumnIndex(headers, 'Exercise'),
    set: findColumnIndex(headers, 'Set'),
    weight: findColumnIndex(headers, 'Weight'),
    reps: findColumnIndex(headers, 'Reps'),
    tonnage: findColumnIndex(headers, 'Tonnage'),
    total: findColumnIndex(headers, 'Total', 'TotalTonnage'),
    notes: findColumnIndex(headers, 'Notes'),
    comments: findColumnIndex(headers, 'Comments')
  };
  
  // V9.0: Сохраняем дату в формате DD.MM.YYYY
  const dateObj = new Date(workout.date);
  const date = formatDateDisplay(dateObj);
  const comments = workout.comments || '';
  
  function createRow(values) {
    const row = new Array(headers.length).fill('');
    Object.keys(values).forEach(key => {
      const colIndex = colIndices[key];
      if (colIndex >= 0) row[colIndex] = values[key];
    });
    return row;
  }
  
  if (workout.type === 'FREE' && workout.notes) {
    ws.appendRow(createRow({
      date: date,
      type: workout.type,
      exercise: 'Свободная',
      set: '',
      weight: '',
      reps: '',
      tonnage: 0,
      total: 0,
      notes: workout.notes,
      comments: comments
    }));
  } else {
    let first = true;
    workout.exercises.forEach(ex => {
      ex.sets.forEach((set, i) => {
        ws.appendRow(createRow({
          date: date,
          type: workout.type,
          exercise: ex.name,
          set: i + 1,
          weight: set.weight,
          reps: set.reps,
          tonnage: set.weight * set.reps,
          total: workout.totalTonnage,
          notes: '',
          comments: first ? comments : ''
        }));
        first = false;
      });
    });
  }
  
  return ContentService.createTextOutput(JSON.stringify({success: true}))
    .setMimeType(ContentService.MimeType.JSON);
}

// ============================================
// V9.0 - ИСТОРИЯ С КОРРЕКТНЫМ ПАРСИНГОМ ДАТ
// ============================================

function getWorkoutHistory() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const ws = ss.getSheetByName('Workouts');
  
  if (!ws) {
    return ContentService.createTextOutput(JSON.stringify({workoutHistory: []}))
      .setMimeType(ContentService.MimeType.JSON);
  }
  
  const data = ws.getDataRange().getValues();
  if (data.length < 2) {
    return ContentService.createTextOutput(JSON.stringify({workoutHistory: []}))
      .setMimeType(ContentService.MimeType.JSON);
  }
  
  const headers = data[0].map(h => String(h).trim());
  
  const dateCol = findColumnIndex(headers, 'Date');
  const typeCol = findColumnIndex(headers, 'Type');
  const exNameCol = findColumnIndex(headers, 'Exercise');
  const setCol = findColumnIndex(headers, 'Set');
  const weightCol = findColumnIndex(headers, 'Weight');
  const repsCol = findColumnIndex(headers, 'Reps');
  const tonnageCol = findColumnIndex(headers, 'Tonnage');
  const totalCol = findColumnIndex(headers, 'Total', 'TotalTonnage');
  const notesCol = findColumnIndex(headers, 'Notes');
  const commentsCol = findColumnIndex(headers, 'Comments');
  
  const workouts = {};
  
  for (let i = 1; i < data.length; i++) {
    const row = data[i];
    
    // V9.0: Получаем дату и конвертируем в единый формат
    const rawDate = dateCol >= 0 ? row[dateCol] : '';
    if (!rawDate) continue;
    
    // Конвертируем в отображаемый формат DD.MM.YYYY
    const displayDate = formatDateDisplay(rawDate);
    // Конвертируем в ISO для сортировки
    const isoDate = parseDateToISO(rawDate);
    
    const type = typeCol >= 0 ? row[typeCol] : '';
    const exName = exNameCol >= 0 ? String(row[exNameCol] || '').trim() : '';
    const weight = weightCol >= 0 ? (parseFloat(row[weightCol]) || 0) : 0;
    const reps = repsCol >= 0 ? (parseFloat(row[repsCol]) || 0) : 0;
    const tonnage = tonnageCol >= 0 ? (parseFloat(row[tonnageCol]) || 0) : 0;
    const total = totalCol >= 0 ? (parseFloat(row[totalCol]) || 0) : 0;
    const notes = notesCol >= 0 ? row[notesCol] : '';
    const comments = commentsCol >= 0 ? row[commentsCol] : '';
    
    const key = `${displayDate}_${type}`;
    
    if (!workouts[key]) {
      workouts[key] = {
        date: displayDate,      // DD.MM.YYYY для отображения
        dateISO: isoDate,       // YYYY-MM-DD для сортировки
        type: type,
        exercises: {},
        totalTonnage: total,
        notes: notes || '',
        comments: comments || ''
      };
    }
    
    if (type === 'FREE' && notes) continue;
    
    if (exName && !workouts[key].exercises[exName]) {
      workouts[key].exercises[exName] = {name: exName, sets: [], tonnage: 0};
    }
    
    if (exName) {
      if (comments && !workouts[key].comments) workouts[key].comments = comments;
      workouts[key].exercises[exName].sets.push({weight, reps});
      workouts[key].exercises[exName].tonnage += tonnage;
    }
  }
  
  // V9.0: Преобразуем в массив и сортируем по ISO дате
  const history = Object.values(workouts).map(w => ({
    ...w,
    exercises: Object.values(w.exercises)
  }));
  
  return ContentService.createTextOutput(JSON.stringify({workoutHistory: history}))
    .setMimeType(ContentService.MimeType.JSON);
}

// ============================================
// ЕЖЕДНЕВНЫЕ ДАННЫЕ (Daily)
// ============================================

function saveDailyData(data) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let ds = ss.getSheetByName('Daily');
  
  if (!ds) {
    ds = ss.insertSheet('Daily');
    ds.appendRow(['Date', 'Nutrition', 'WakeTime', 'Sleep', 'TrainingDone', 'TrainingType', 'Weight', 'Pullups', 'Bench', 'Notes']);
    ds.getRange(1, 1, 1, 10).setFontWeight('bold').setBackground('#3498db');
  }
  
  const allData = ds.getDataRange().getValues();
  const headers = allData[0].map(h => String(h).trim());
  
  const colIndices = {
    date: findColumnIndex(headers, 'Date'),
    nutrition: findColumnIndex(headers, 'Nutrition'),
    wakeTime: findColumnIndex(headers, 'WakeTime'),
    sleep: findColumnIndex(headers, 'Sleep', 'SleepHours'),
    trainingDone: findColumnIndex(headers, 'TrainingDone'),
    trainingType: findColumnIndex(headers, 'TrainingType'),
    weight: findColumnIndex(headers, 'Weight'),
    pullups: findColumnIndex(headers, 'Pullups'),
    bench: findColumnIndex(headers, 'Bench'),
    notes: findColumnIndex(headers, 'Notes')
  };
  
  const date = data.date || formatDateDisplay(new Date());
  const dataValues = {
    date: date,
    nutrition: data.nutrition || '',
    wakeTime: data.wakeTime || '',
    sleep: data.sleepHours || data.sleep || '',
    trainingDone: data.trainingDone ? 'Да' : 'Нет',
    trainingType: data.trainingType || '',
    weight: data.weight || '',
    pullups: data.pullups || '',
    bench: data.bench || '',
    notes: data.notes || ''
  };
  
  let found = false;
  let rowIndex = -1;
  
  for (let i = 1; i < allData.length; i++) {
    const rowDate = formatDateDisplay(allData[i][colIndices.date]);
    if (rowDate === date) {
      rowIndex = i + 1;
      found = true;
      break;
    }
  }
  
  if (found) {
    Object.keys(colIndices).forEach(key => {
      const colIndex = colIndices[key];
      if (colIndex >= 0) {
        ds.getRange(rowIndex, colIndex + 1).setValue(dataValues[key]);
      }
    });
  } else {
    const newRow = new Array(headers.length).fill('');
    Object.keys(colIndices).forEach(key => {
      const colIndex = colIndices[key];
      if (colIndex >= 0) {
        newRow[colIndex] = dataValues[key];
      }
    });
    ds.appendRow(newRow);
  }
  
  return ContentService.createTextOutput(JSON.stringify({success: true}))
    .setMimeType(ContentService.MimeType.JSON);
}

function getDailyData() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const ds = ss.getSheetByName('Daily');
  
  if (!ds) {
    return ContentService.createTextOutput(JSON.stringify({dailyData: {}}))
      .setMimeType(ContentService.MimeType.JSON);
  }
  
  const data = ds.getDataRange().getValues();
  if (data.length < 2) {
    return ContentService.createTextOutput(JSON.stringify({dailyData: {}}))
      .setMimeType(ContentService.MimeType.JSON);
  }
  
  const headers = data[0].map(h => String(h).trim());
  
  const dateCol = findColumnIndex(headers, 'Date');
  const nutritionCol = findColumnIndex(headers, 'Nutrition');
  const wakeTimeCol = findColumnIndex(headers, 'WakeTime');
  const sleepCol = findColumnIndex(headers, 'SleepHours', 'Sleep');
  const trainingDoneCol = findColumnIndex(headers, 'TrainingDone');
  const trainingTypeCol = findColumnIndex(headers, 'TrainingType');
  const weightCol = findColumnIndex(headers, 'Weight');
  const pullupsCol = findColumnIndex(headers, 'Pullups');
  const benchCol = findColumnIndex(headers, 'Bench');
  const notesCol = findColumnIndex(headers, 'Notes');
  
  const dailyData = {};
  
  for (let i = 1; i < data.length; i++) {
    const row = data[i];
    const dateValue = dateCol >= 0 ? row[dateCol] : '';
    
    if (!dateValue) continue;
    
    const dateKey = formatDateDisplay(dateValue);
    
    dailyData[dateKey] = {
      date: dateKey,
      nutrition: nutritionCol >= 0 ? row[nutritionCol] : '',
      wakeTime: wakeTimeCol >= 0 ? formatTime(row[wakeTimeCol]) : '',
      sleep: sleepCol >= 0 ? row[sleepCol] : '',
      trainingDone: trainingDoneCol >= 0 ? row[trainingDoneCol] : '',
      trainingType: trainingTypeCol >= 0 ? row[trainingTypeCol] : '',
      weight: weightCol >= 0 ? row[weightCol] : '',
      pullups: pullupsCol >= 0 ? row[pullupsCol] : '',
      bench: benchCol >= 0 ? row[benchCol] : '',
      notes: notesCol >= 0 ? row[notesCol] : ''
    };
  }
  
  return ContentService.createTextOutput(JSON.stringify({dailyData}))
    .setMimeType(ContentService.MimeType.JSON);
}

// ============================================
// НЕДЕЛЬНЫЕ ДАННЫЕ (Data)
// ============================================

function saveWeeklyData(data) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let ws = ss.getSheetByName('Data');
  
  if (!ws) {
    ws = ss.insertSheet('Data');
    ws.appendRow(['Week', 'Weight', 'Pullups', 'Bench', 'Workouts', 'Deficit', 'Macros', 'Sleep', 'WakeTime', 'Status']);
    ws.getRange(1, 1, 1, 10).setFontWeight('bold').setBackground('#e74c3c');
  }
  
  const allData = ws.getDataRange().getValues();
  const headers = allData[0].map(h => String(h).trim());
  
  const colIndices = {
    week: findColumnIndex(headers, 'Week'),
    weight: findColumnIndex(headers, 'Weight'),
    pullups: findColumnIndex(headers, 'Pullups'),
    bench: findColumnIndex(headers, 'Bench'),
    workouts: findColumnIndex(headers, 'Workouts'),
    deficit: findColumnIndex(headers, 'Deficit'),
    macros: findColumnIndex(headers, 'Macros'),
    sleep: findColumnIndex(headers, 'Sleep', 'SleepHours'),
    wakeTime: findColumnIndex(headers, 'WakeTime'),
    status: findColumnIndex(headers, 'Status', 'DailyStatus')
  };
  
  function createRow(values) {
    const row = new Array(headers.length).fill('');
    Object.keys(values).forEach(key => {
      const colIndex = colIndices[key];
      if (colIndex >= 0) row[colIndex] = values[key];
    });
    return row;
  }
  
  function updateRow(rowIndex, values) {
    Object.keys(values).forEach(key => {
      const colIndex = colIndices[key];
      if (colIndex >= 0) {
        ws.getRange(rowIndex, colIndex + 1).setValue(values[key]);
      }
    });
  }
  
  if (data.initialBench !== undefined) {
    let found = false;
    for (let i = 1; i < allData.length; i++) {
      if (allData[i][colIndices.week] === 'initialBench') {
        updateRow(i + 1, { weight: data.initialBench });
        found = true;
        break;
      }
    }
    if (!found) {
      ws.appendRow(createRow({
        week: 'initialBench',
        weight: data.initialBench
      }));
    }
  }
  
  if (data.week && data.weekData) {
    const wd = data.weekData;
    let found = false;
    
    for (let i = 1; i < allData.length; i++) {
      if (allData[i][colIndices.week] == data.week) {
        updateRow(i + 1, {
          week: data.week,
          weight: wd.weight || 0,
          pullups: wd.pullups || 0,
          bench: wd.bench || 0,
          workouts: wd.workouts || 0,
          deficit: wd.deficit || 0,
          macros: wd.macros || 0,
          sleep: wd.sleepHours || 0,
          wakeTime: wd.wakeTime || '',
          status: wd.dailyStatus || ''
        });
        found = true;
        break;
      }
    }
    
    if (!found) {
      ws.appendRow(createRow({
        week: data.week,
        weight: wd.weight || 0,
        pullups: wd.pullups || 0,
        bench: wd.bench || 0,
        workouts: wd.workouts || 0,
        deficit: wd.deficit || 0,
        macros: wd.macros || 0,
        sleep: wd.sleepHours || 0,
        wakeTime: wd.wakeTime || '',
        status: wd.dailyStatus || ''
      }));
    }
  }
  
  return ContentService.createTextOutput(JSON.stringify({success: true}))
    .setMimeType(ContentService.MimeType.JSON);
}

function getWeeklyData() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const ws = ss.getSheetByName('Data');
  
  if (!ws) {
    return ContentService.createTextOutput(JSON.stringify({weekData: {}, initialBench: null}))
      .setMimeType(ContentService.MimeType.JSON);
  }
  
  const data = ws.getDataRange().getValues();
  if (data.length < 2) {
    return ContentService.createTextOutput(JSON.stringify({weekData: {}, initialBench: null}))
      .setMimeType(ContentService.MimeType.JSON);
  }
  
  const headers = data[0].map(h => String(h).trim());
  
  const weekCol = findColumnIndex(headers, 'Week');
  const weightCol = findColumnIndex(headers, 'Weight');
  const pullupsCol = findColumnIndex(headers, 'Pullups');
  const benchCol = findColumnIndex(headers, 'Bench');
  const workoutsCol = findColumnIndex(headers, 'Workouts');
  const deficitCol = findColumnIndex(headers, 'Deficit');
  const macrosCol = findColumnIndex(headers, 'Macros');
  const sleepCol = findColumnIndex(headers, 'Sleep', 'SleepHours');
  const wakeTimeCol = findColumnIndex(headers, 'WakeTime');
  const statusCol = findColumnIndex(headers, 'Status', 'DailyStatus');
  
  const weekData = {};
  let initialBench = null;
  
  for (let i = 1; i < data.length; i++) {
    const row = data[i];
    const weekKey = weekCol >= 0 ? row[weekCol] : row[0];
    
    if (weekKey === 'initialBench') {
      initialBench = weightCol >= 0 ? row[weightCol] : row[1];
    } else if (weekKey) {
      weekData[weekKey] = {
        weight: weightCol >= 0 ? row[weightCol] : 0,
        pullups: pullupsCol >= 0 ? row[pullupsCol] : 0,
        bench: benchCol >= 0 ? row[benchCol] : 0,
        workouts: workoutsCol >= 0 ? row[workoutsCol] : 0,
        deficit: deficitCol >= 0 ? row[deficitCol] : 0,
        macros: macrosCol >= 0 ? row[macrosCol] : 0,
        sleepHours: sleepCol >= 0 ? row[sleepCol] : 0,
        wakeTime: wakeTimeCol >= 0 ? row[wakeTimeCol] : '',
        dailyStatus: statusCol >= 0 ? row[statusCol] : ''
      };
    }
  }
  
  return ContentService.createTextOutput(JSON.stringify({weekData, initialBench}))
    .setMimeType(ContentService.MimeType.JSON);
}

// ============================================
// ACTUAL NUTRITION
// ============================================

function getActualNutrition() {
  try {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const sheet = ss.getSheetByName('ActualNutrition');
    
    if (!sheet) {
      return ContentService.createTextOutput(JSON.stringify({
        success: false,
        message: 'ActualNutrition sheet not found',
        data: null
      })).setMimeType(ContentService.MimeType.JSON);
    }
    
    const allData = sheet.getDataRange().getValues();
    if (allData.length <= 1) {
      return ContentService.createTextOutput(JSON.stringify({
        success: false,
        message: 'No data in ActualNutrition',
        data: null
      })).setMimeType(ContentService.MimeType.JSON);
    }
    
    const headers = allData[0].map(h => String(h).trim());
    const colIndices = {
      date: findColumnIndex(headers, 'Date'),
      calories: findColumnIndex(headers, 'Calories'),
      protein: findColumnIndex(headers, 'Protein'),
      fats: findColumnIndex(headers, 'Fats'),
      carbs: findColumnIndex(headers, 'Carbs'),
      notes: findColumnIndex(headers, 'Notes'),
      updatedBy: findColumnIndex(headers, 'UpdatedBy'),
      source: findColumnIndex(headers, 'Source'),
      period: findColumnIndex(headers, 'Period')
    };
    
    let totalCalories = 0;
    let totalProtein = 0;
    let totalFats = 0;
    let totalCarbs = 0;
    let count = 0;
    let allNotes = [];
    let firstDate = '';
    let lastDate = '';
    
    for (let i = 1; i < allData.length; i++) {
      const row = allData[i];
      const calories = parseFloat(row[colIndices.calories]) || 0;
      const protein = parseFloat(row[colIndices.protein]) || 0;
      const fats = parseFloat(row[colIndices.fats]) || 0;
      const carbs = parseFloat(row[colIndices.carbs]) || 0;
      
      if (calories > 0) {
        totalCalories += calories;
        totalProtein += protein;
        totalFats += fats;
        totalCarbs += carbs;
        count++;
        
        const dateVal = row[colIndices.date];
        if (!firstDate && dateVal) firstDate = dateVal;
        if (dateVal) lastDate = dateVal;
        
        const note = row[colIndices.notes];
        if (note && String(note).trim()) {
          allNotes.push(String(note).trim());
        }
      }
    }
    
    if (count === 0) {
      return ContentService.createTextOutput(JSON.stringify({
        success: false,
        message: 'No valid nutrition data found',
        data: null
      })).setMimeType(ContentService.MimeType.JSON);
    }
    
    function formatDateShort(d) {
      if (!d) return '';
      if (d instanceof Date) {
        const dd = String(d.getDate()).padStart(2, '0');
        const mm = String(d.getMonth() + 1).padStart(2, '0');
        return `${dd}.${mm}`;
      }
      const str = String(d);
      if (str.includes('-')) {
        const parts = str.split('-');
        if (parts.length === 3) return `${parts[2]}.${parts[1]}`;
      }
      if (str.match(/^\d{2}\.\d{2}\.\d{4}$/)) {
        return str.substring(0, 5);
      }
      return str;
    }
    
    const dateRange = firstDate === lastDate 
      ? formatDateShort(lastDate) 
      : `${formatDateShort(firstDate)} - ${formatDateShort(lastDate)}`;
    
    const dailyEntries = [];
    for (let i = 1; i < allData.length; i++) {
      const row = allData[i];
      const calories = parseFloat(row[colIndices.calories]) || 0;
      if (calories > 0) {
        dailyEntries.push({
          date: formatDateShort(row[colIndices.date]),
          calories: Math.round(calories),
          protein: Math.round(parseFloat(row[colIndices.protein]) || 0),
          fats: Math.round(parseFloat(row[colIndices.fats]) || 0),
          carbs: Math.round(parseFloat(row[colIndices.carbs]) || 0),
          note: row[colIndices.notes] ? String(row[colIndices.notes]).trim() : ''
        });
      }
    }
    
    const actualData = {
      calories: Math.round(totalCalories / count),
      protein: Math.round(totalProtein / count),
      fats: Math.round(totalFats / count),
      carbs: Math.round(totalCarbs / count),
      daysCount: count,
      dateRange: dateRange,
      date: dateRange,
      notes: `Среднее за ${count} дней`,
      allNotes: allNotes,
      dailyEntries: dailyEntries,
      updatedBy: 'Coach',
      source: 'calculated',
      period: 'average'
    };
    
    return ContentService.createTextOutput(JSON.stringify({
      success: true,
      data: actualData
    })).setMimeType(ContentService.MimeType.JSON);
    
  } catch (error) {
    return ContentService.createTextOutput(JSON.stringify({
      success: false,
      message: error.toString(),
      data: null
    })).setMimeType(ContentService.MimeType.JSON);
  }
}

function saveActualNutrition(data) {
  try {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    let sheet = ss.getSheetByName('ActualNutrition');
    
    if (!sheet) {
      sheet = ss.insertSheet('ActualNutrition');
      const headers = ['Date', 'Calories', 'Protein', 'Fats', 'Carbs', 'Notes', 'UpdatedBy', 'Source', 'Period'];
      sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
      sheet.getRange(1, 1, 1, headers.length)
        .setFontWeight('bold')
        .setBackground('#4CAF50')
        .setFontColor('white');
      sheet.setFrozenRows(1);
    }
    
    const allData = sheet.getDataRange().getValues();
    const headers = allData[0].map(h => String(h).trim());
    
    const colIndices = {
      date: findColumnIndex(headers, 'Date'),
      calories: findColumnIndex(headers, 'Calories'),
      protein: findColumnIndex(headers, 'Protein'),
      fats: findColumnIndex(headers, 'Fats'),
      carbs: findColumnIndex(headers, 'Carbs'),
      notes: findColumnIndex(headers, 'Notes'),
      updatedBy: findColumnIndex(headers, 'UpdatedBy'),
      source: findColumnIndex(headers, 'Source'),
      period: findColumnIndex(headers, 'Period')
    };
    
    function createRow(values) {
      const row = new Array(headers.length).fill('');
      Object.keys(values).forEach(key => {
        const colIndex = colIndices[key];
        if (colIndex >= 0) row[colIndex] = values[key];
      });
      return row;
    }
    
    const dateStr = data.date || formatDateDisplay(new Date());
    
    const newRow = createRow({
      date: dateStr,
      calories: data.calories || 0,
      protein: data.protein || 0,
      fats: data.fats || 0,
      carbs: data.carbs || 0,
      notes: data.notes || '',
      updatedBy: data.updatedBy || 'Coach',
      source: data.source || 'manual',
      period: data.period || 'week'
    });
    
    sheet.appendRow(newRow);
    
    return ContentService.createTextOutput(JSON.stringify({
      success: true,
      message: 'Actual nutrition data saved successfully'
    })).setMimeType(ContentService.MimeType.JSON);
    
  } catch (error) {
    return ContentService.createTextOutput(JSON.stringify({
      success: false,
      message: error.toString()
    })).setMimeType(ContentService.MimeType.JSON);
  }
}
